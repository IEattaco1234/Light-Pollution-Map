#!/usr/bin/env python3
"""Serve Nocturne locally with a fixed-provider weather relay. No dependencies."""
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from urllib.parse import urlsplit,parse_qs,urlencode
from urllib.request import Request,urlopen
from pathlib import Path
import json,os,sys,math
BASE=Path(__file__).resolve().parent
ALLOWED={'latitude','longitude','hourly','timezone','timeformat','forecast_days','temperature_unit','wind_speed_unit'}
FIELDS={'cloud_cover','cloud_cover_low','cloud_cover_mid','cloud_cover_high','precipitation_probability','wind_speed_10m','relative_humidity_2m','temperature_2m','dew_point_2m'}
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(BASE),**kwargs)
 def do_GET(self):
  url=urlsplit(self.path)
  if url.path!='/api/weather':return super().do_GET()
  try:
   values=parse_qs(url.query,strict_parsing=True)
   if set(values)-ALLOWED or any(len(v)!=1 for v in values.values()):raise ValueError('Unsupported parameters')
   params={k:v[0] for k,v in values.items()}
   lat=float(params['latitude']);lon=float(params['longitude'])
   if not math.isfinite(lat) or not math.isfinite(lon) or not -90<=lat<=90 or not -180<=lon<=180:raise ValueError('Invalid coordinates')
   if not set(params.get('hourly','').split(','))<=FIELDS:raise ValueError('Unsupported weather fields')
   if not 1<=int(params.get('forecast_days','9'))<=9:raise ValueError('Forecast limit is nine days')
   if params.get('timezone','UTC')!='UTC' or params.get('timeformat','unixtime')!='unixtime':raise ValueError('Use UTC epoch timestamps')
   endpoint='https://api.open-meteo.com/v1/forecast?'+urlencode(params)
   with urlopen(Request(endpoint,headers={'User-Agent':'Nocturne-FieldPlanner/2.0'}),timeout=12) as response:body=response.read(2_000_000)
   json.loads(body)
   self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(body)
  except (ValueError,KeyError) as exc:self.send_error(400,str(exc))
  except Exception as exc:
   body=json.dumps({'error':True,'reason':'Weather provider unavailable: '+str(exc)}).encode()
   self.send_response(502);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(body)
if __name__=='__main__':
 port=int(sys.argv[1]) if len(sys.argv)>1 else 8000
 print(f'Open http://localhost:{port}/index.html — press Ctrl+C to stop',flush=True)
 ThreadingHTTPServer(('127.0.0.1',port),Handler).serve_forever()
