# Naked-eye star estimate / Nocturne model1.1

The previous UI counted all included catalog stars brighter than magnitude6 above10° regardless of skyglow. Similar ~2,000 results at nearby locations were geometric counts, not visual predictions.

The new module counts actual HYGv4.1 catalog entries that meet a modeled naked-eye threshold for the selected location/date/time. The catalog was actually downloaded and expanded to magnitude8.0 (41,487 entries, Sun excluded), avoiding the old6.5 ceiling. No fixed star total is assigned to a Bortle class.

## Visibility model

Crumey(2014), *Human contrast threshold and astronomical visibility*, MNRAS442,2600–2619, full point-source Eq34 with Blackwell coefficients Eq28:

    t = B^0.25
    q = a1 + a2t + a3t²
    ΔI_raw = [t(√q + a4 + a5t)]²
    (a1,a2,a3,a4,a5) = (5.949e−8,−2.389e−7,2.459e−7,4.120e−4,−4.225e−4)
    m_lim = −2.5log10(F × ΔI_envelope / 2.54e−6)

B is background luminance in cd/m². Sky magnitudeμ is converted using B=108000×10^(−0.4μ). The nominal field factorF=2 and sensitivity range1.4–2.4 follow the paper's illustrative naked-eye discussion (§3.1).

The simpler Eq53 scotopic approximation has a bright-background turnover and must not be extrapolated unchecked into lunar glare. Even the full Eq34 empirical fit has a very small (~0.03mag) turnover across part of the mesopic transition. This app deliberately applies a **monotonic threshold envelope**: once a local maximum in required illuminance is reached, retain it until the raw threshold rises above it. The turning point is located numerically from the analytic derivative of Eq34. This prevents added background light from improving the app's star detectability. It is an explicit application regularization, not a claim of new empirical validation or a modification attributed to Crumey. Inputs are restricted to the source data's broad luminance range with a low-background floor.

Primary source actually retrieved and inspected: https://crumey.co.uk/archive/astro/mnras.pdf ; https://doi.org/10.1093/mnras/stu992 . Do not interpret the count range as a statistical confidence interval.

The archived2015 atlas brightness-category bounds and observer-factor range produce scenario bounds. For the brightest unbounded atlas category, the lower estimate is0 instead of pretending there is a known finite bright-side bound. Skyglow is treated as uniform across the sky because the atlas gives modeled zenith brightness; real light domes and local glare are not resolved.

Stars are precessed from J2000 to the observation date and counted above10°. Differential extinction beyond the zenith is assumed at0.20mag/airmass (scenario0.12–0.30), not read from weather measurements. The overall field factor includes typical zenith/observer loss, so only excess air mass is added. Catalog entries can include multiple stars not resolved by a naked eye.

## Moon and weather

Krisciunas&Schaefer(1991), *A model of the brightness of moonlight*, PASP103,1033–1039, Eq3/15/19/20/21, adds lunar skyglow separately around each star using Moon phase, altitude and angular separation. Scattering extinction is assumed0.20mag/airmass. A0.5–1.5 Moon-contribution sensitivity factor contributes to bounds; this is an app scenario, not a measured uncertainty. Added Moon light is never allowed to improve the clear-sky detection threshold. Near the Moon/high backgrounds, this remains only a simplified planning model.

Primary paper actually retrieved and inspected: https://articles.adsabs.harvard.edu/pdf/1991PASP..103.1033K ; https://doi.org/10.1086/132921 . The model assumes clear atmosphere, not live aerosol/seeing/transparency data.

Forecast cloud percentage is recorded and explained but is not used as an invented uniform multiplier: cloud placement and optical thickness determine which stars disappear. The count is explicitly a **clear-sky estimate including modeled Moon light**. clearSkyCount is the moonless baseline. Daylight/twilight returns no current count, since this is a night-vision model; baseline potential is retained.

## API

    NocturneStarEstimate.estimate(date,{lat,lon},{cloudCover?,cloudFetchedAt?})

Returns count/lower/upper (null outside nighttime), clearSkyCount/clearSkyLower/clearSkyUpper, limitingMag (Moon-adjusted zenith), moonlessLimitingMag, minimumAltitude10, status, Moon/cloud details, conditionNotes, assumptions, modelVersion and source links. status is night/daylight/twilight/unavailable. These are modeled naked-eye estimates, not camera-star counts or guarantees.

## Checks

At identical latitude/date with sky magnitude varied17.2→21.99, nominal estimates rose436→2,181; a fixed sky-independent2,000 result is no longer possible by construction. A Great Basin example with a66.7%-illuminated Moon45° up gave859 stars versus2,245 moonless potential. Daylight and twilight returned null. All bounds contained their nominal result. Regression checks also sampled60,003log-spaced brightness/observer combinations,3,001added-Moon-background increments, and10full-catalog cases: the threshold and counts never improve when sky brightness increases. These are deterministic software checks, not field validation of the model.

The sky layer retains its CC BY-NC4.0 license; HYG retains CC BY-SA4.0. Refer to their bundled license files. This document describes the app model and does not change third-party rights.
