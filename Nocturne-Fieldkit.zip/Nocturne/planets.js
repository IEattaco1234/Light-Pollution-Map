/* Nocturne planetary close approaches, calculated offline with Astronomy Engine 2.1.19 (MIT).
   Searches apparent geocentric angular separation minima; NOT exact RA conjunction times. */
(function(root){
'use strict';
const A=root.Astronomy,N=root.NocturneAstro,DAY=86400000,planets=['Mercury','Venus','Mars','Jupiter','Saturn'];
const globalCache=new Map(),localCache=new Map();
function angular(v,w){const dot=v.x*w.x+v.y*w.y+v.z*w.z,r=Math.hypot(v.x,v.y,v.z)*Math.hypot(w.x,w.y,w.z);return Math.acos(Math.max(-1,Math.min(1,dot/r)))*180/Math.PI;}
function separation(a,b,t){const d=new Date(t);return angular(A.GeoVector(a,d,true),A.GeoVector(b,d,true));}
function refine(a,b,left,right){const phi=(Math.sqrt(5)-1)/2;let x1=right-phi*(right-left),x2=left+phi*(right-left),y1=separation(a,b,x1),y2=separation(a,b,x2);for(let i=0;i<28;i++){if(y1<y2){right=x2;x2=x1;y2=y1;x1=right-phi*(right-left);y1=separation(a,b,x1);}else{left=x1;x1=x2;y1=y2;x2=left+phi*(right-left);y2=separation(a,b,x2);}}const time=(left+right)/2;return{time,separation:separation(a,b,time)};}
function globalEvents(afterDate,days){
 const startDay=new Date(afterDate).toISOString().slice(0,10),key=startDay+'|'+days;if(globalCache.has(key))return globalCache.get(key);
 const start=Date.parse(startDay+'T00:00:00Z')-2*DAY,num=Math.ceil(days)+5,samples=[];
 for(let i=0;i<num;i++){const date=new Date(start+i*DAY),vectors={};for(const body of planets)vectors[body]=A.GeoVector(body,date,true);samples.push({time:+date,vectors});}
 const out=[];
 for(let a=0;a<planets.length;a++)for(let b=a+1;b<planets.length;b++){
  const bodyA=planets[a],bodyB=planets[b],values=samples.map(s=>angular(s.vectors[bodyA],s.vectors[bodyB]));
  for(let i=1;i<samples.length-1;i++)if(values[i]<=values[i-1]&&values[i]<=values[i+1]&&values[i]<3.5){
   const event=refine(bodyA,bodyB,samples[i-1].time,samples[i+1].time);
   if(event.separation<=3)out.push({time:event.time,date:new Date(event.time),names:[bodyA,bodyB],bodyA,bodyB,separation:event.separation});
  }
 }
 out.sort((a,b)=>a.time-b.time);globalCache.set(key,out);return out;
}
function nearNight(event,lat,lon){
 let best=null;
 // A nearby observable moment can differ from exact closest approach. Search +/-18h.
 for(let time=event.time-18*3600000;time<=event.time+18*3600000;time+=60*60000){
  const date=new Date(time),sunAlt=N.sunAlt(date,lat,lon);if(sunAlt>=-6)continue;
  const pa=N.bodyPosition(event.bodyA,date,lat,lon),pb=N.bodyPosition(event.bodyB,date,lat,lon),minAlt=Math.min(pa.alt,pb.alt);if(minAlt<5)continue;
  if(!best||minAlt>best.minAlt)best={date,altitudeA:pa.alt,altitudeB:pb.alt,minAlt,sunAlt,separation:separation(event.bodyA,event.bodyB,time),description:'Nearby sample: both planets above 5°, Sun below −6°. Geometry only; weather and terrain not checked.'};
 }
 return best;
}
root.NocturnePlanetEvents=function(afterDate,lat,lon,days=365){
 afterDate=new Date(afterDate);days=Math.min(730,Math.max(1,Number(days)||365));const end=+afterDate+days*DAY,key=[afterDate.toISOString().slice(0,10),lat,lon,days].join('|');let result=localCache.get(key);
 if(!result){result=globalEvents(afterDate,days).map(e=>{const pa=N.bodyPosition(e.bodyA,e.date,lat,lon),pb=N.bodyPosition(e.bodyB,e.date,lat,lon),sunAlt=N.sunAlt(e.date,lat,lon),localBest=nearNight(e,lat,lon);return{...e,id:'planet-'+e.bodyA+'-'+e.bodyB+'-'+e.date.toISOString(),type:'planetary-close-approach',name:e.bodyA+' & '+e.bodyB+' close approach',altitudeA:pa.alt,altitudeB:pb.alt,sunAlt,localVisible:pa.alt>0&&pb.alt>0&&sunAlt<-6,localBest,source:'Astronomy Engine 2.1.19',sourceUrl:'https://github.com/cosinekitty/astronomy',description:'Minimum apparent geocentric angular separation under 3°. Calculated closest approach, not an exact right-ascension conjunction. Separation is geocentric; local altitudes use topocentric positions.'};});localCache.set(key,result);}
 return result.filter(e=>e.time>=+afterDate&&e.time<=end);
};
})(typeof window!=='undefined'?window:globalThis);
