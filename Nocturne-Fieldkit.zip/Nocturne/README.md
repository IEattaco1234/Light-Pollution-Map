# Nocturne — Astrophotography Field Planner / Fieldkit 05

## Open or install

Open **index.html** in a modern browser for the self-contained app. Internet is needed to fetch weather. Astronomy catalogs, Moon/planet calculations, state outlines and the archived light-pollution layer are bundled offline.

For a local installable web app and reliable geolocation, use Python 3 (no extra packages):

    python3 server.py

Open http://localhost:8000/index.html. Keep the terminal open and use Ctrl+C to stop. On Windows, `py server.py` may be the appropriate launcher. A browser may offer Install/Add to Home Screen when served from localhost or HTTPS. The included localhost server relays only the fixed Open-Meteo endpoint. Static HTTPS hosting uses the provider directly. Review data licenses before public or commercial deployment.

## Guide and photo aiming

The **Guide** button is in the top bar beside **Data & sources**. It opens a popup with live values for the selected location, target, date and time, plus phone and separate-camera tutorials. Direction is azimuth from true north; altitude is height above the horizon. These are session coordinates, not a live reading of the phone's orientation.

The guide names iPhone **Measure → Level** and **Compass**, and Android **Physics Toolbox Sensor Suite** (Vieyra Software), with links to official support/developer pages. It explains compass north-reference differences, magnetic interference, aligning a phone edge with the camera lens axis, checking/zeroing the horizon reference, pitch versus roll and complementary angles. A phone held nearby without axis alignment does not measure the lens angle. A rear phone camera points differently from the phone's top edge. Phone sensors are approximate and cannot replace a telescope finder or plate solving.

Phone photo guidance covers supported iPhone Night mode and Pixel Night Sight/Astrophotography, stability, timers and test shots. Separate-camera starting settings are examples for a wide-angle star field, not guaranteed exposures for every lens or galaxy. Focus, star trailing, weather and equipment need checking. The existing glossary and chart explanations are inside the same Guide popup.

## Map and point inspection

The map covers California and Nevada and the surrounding rectangular region. Colors now fill the entire view from an actual published sky-brightness dataset. Black is the darkest estimated Bortle class; dark blue/blue, green, yellow, orange and red represent progressively brighter modeled skies. Marker colors and the legend use the same palette, including in Red Field theme.

Drag to pan, use +/− or Ctrl+scroll to zoom, Fit to reset, and **Expand** for a large map. Panning is limited to the bundled data extent. Click a marker or any point for a popup with:

- Estimated Bortle value/range and dataset year.
- Coordinates and selected session time.
- A modeled naked-eye star estimate and scenario range above 10°, using sky brightness, Moonlight and atmospheric extinction. Clear sky is assumed; cloud forecasts are flagged separately.
- Milky Way **core** altitude/availability and a separate **band** outlook using geometry, modeled skyglow, Moon and available cloud forecast.

The winter band can be visible when the Sagittarius core is below the horizon. The outlook is a heuristic, not a visibility guarantee. Weather is marked unchecked if no forecast exists at the inspected point/time. Within CA/NV, a background click creates a temporary planning preview and fetches weather there. It does not add a row to the location list or persist a map pin. Use **Save map pin** in the popup to keep it. Saved custom pins have a **Delete** button in the right-hand list and popup. Deletion removes the pin and its favorite reference from this browser; it does not delete the built-in scouting catalog. Older pins from earlier versions remain available for explicit deletion. Outside either state, points can be inspected without becoming planning destinations. This is not a road-navigation or terrain map, and coordinates do not verify access or parking.

## Location tracking and GPS pins

Click **Follow my location** and allow browser location access. A live blue dot appears on the map once a position is available, and distances use that position. The adjacent **Use your location as a marked pin** button is gray and disabled until a valid position arrives.

Click the pin button to save a fixed snapshot to the map and right-hand location list, select it for planning, and fetch its forecast. The list clears any search, state, darkness or Saved-only filters so the pin is visible. Repeated clicks at the same coordinates reuse the existing pin. Use its **Delete** button to remove it. Tracking can move independently of the saved pin; stopping tracking, a GPS error, or revoked permission clears the live position and disables the pin button. Saved pins stay available after tracking stops or the page reloads, when browser storage is available.

Saved GPS pins are supported inside California and Nevada. Positions outside these states show an explanation. If location is denied, times out or is unavailable, the status explains how to retry. Use HTTPS or localhost for browser location access. Standalone downloaded field packs always reopen with tracking off and the pin button disabled.

The location list now uses filled Bortle badges with white outlines, dark outer edges and contrasting numbers, so the black Bortle 1 category remains visible in all themes. Location names, details and selected-row borders are also clearer.

## Light-pollution source and required license

**World Atlas of Artificial Night Sky Brightness 2015**, Falchi et al. (2016), GFZ Data Services, DOI https://doi.org/10.5880/GFZ.1.4.2016.001 . Original model uses satellite inputs from 2014. This release actually downloaded and decoded the official georeferenced KMZ quicklook JPEG tiles. It does not claim to use raw floating-point GeoTIFF luminance.

The bundled 1360×920 grid covers −127° to −110° longitude, 31.5° to 43° latitude at 0.0125° spacing. Fourteen original atlas categories are retained. Nearest-palette category recovery and nearest-neighbor resampling introduce uncertainty near boundaries. Brightness values are category bounds/midpoints, not precise measurements. The conventional Bortle conversion is approximate; Bortle is a visual observational scale with no unique physical conversion. Dataset year, estimated values and ranges remain visible.

The atlas models historic moonless zenith skyglow. It does not include today's lighting changes, clouds, Moon, local lamps, terrain or your eyesight. Refresh data updates weather, not the 2015 atlas. Source metadata and methods are in **light-pollution-source.json** and **light-pollution.js**.

**The atlas layer is licensed CC BY-NC 4.0 (noncommercial reuse with attribution).** See LICENSE-WorldAtlas.txt and https://creativecommons.org/licenses/by-nc/4.0/ . Commercial use requires suitable additional rights or a different source. Other bundled code/data retain their own licenses; this is not a blanket noncommercial license over unrelated app code.

## Planning and offline use

Simple mode is the default for first-time users. It shows a suggested night near the top, the map and location list, selected-sky summary, seven-day nearby suggestions, target cards, and events. Turn Simple mode off for all graphs, hourly tables, Moon details and detailed target positions. The page scrolls through sections using the left contents menu (horizontal on small screens). Eight themes and mode preference persist in your browser.

There are 38 curated scouting areas plus custom pins. Nearby suggestions compare up to three areas nearest the starting city or GPS position, within the selected straight-line radius. They are weather-based suggestions; current darkness and site access still require checking. The automatic rule needs at least two consecutive hourly samples with clouds≤25%, precipitation probability≤20%, Sun below−18°, target above25°, and Moon interference index≤35/100. Wind and dew are displayed for judgment, not scored. Missing/stale weather does not create a recommendation.

Weather suggestions cover the next seven local nights only. The cloud percentage and illuminated Moon disk percentage are different quantities; no percentage of artificial light pollution is calculated. All displayed times are Pacific, including user pins in Nevada locations that use Mountain time locally.

Use **Refresh data** while connected, then **Download this location** for a standalone HTML field pack. The field pack retains the selected destination (including an unsaved preview), forecast timestamp, offline map, star-visibility model, astronomy and Guide. Downloading a preview does not silently save it to the browser location list. Its Simple calendar uses that destination. Forecasts cannot refresh offline. A failed refresh retains the old forecast and timestamp. Automatic daily checks run only while the app is open and connected. **Follow my location** is separate browser GPS permission; availability/accuracy depend on hardware and secure context. No live position is uploaded by this app.

**Add reminder** downloads an .ics file. Import it into a calendar to use its one-hour alarm. The website does not send background notifications. Meteor peaks without exact times remain all-day events.

## Other sources

- **Weather:** Open-Meteo Forecast API, https://open-meteo.com/en/docs . Live model forecasts, not station observations. Retrieval time is not model issue time. The provider's grid point can differ from the selected coordinate. Units are %, km/h and °C. Check applicable provider terms before commercial use.
- **Sun, Moon, planets and eclipses:** Astronomy Engine 2.1.19, https://github.com/cosinekitty/astronomy , MIT; license included. Calculations work offline. Moon interference is a heuristic, not measured sky brightness or exposure compensation.
- **Galaxies, nebulae and clusters:** actual OpenNGC rows, https://github.com/mattiaverga/OpenNGC ; source subsets and CC BY-SA 4.0 license included. Coordinates are J2000, precessed for target positioning; V magnitudes are integrated brightness where available. Seasons, beginner tips and gear labels are editorial guidance.
- **Stars and constellation guide stars:** actual HYG v4.1 subset, https://github.com/astronexus/HYG-Database , David Nash/Astronexus, CC BY-SA 4.0; license included. The catalog has been expanded to 41,487 actual entries at mag≤8.0 to avoid truncating estimates at dark sites. The naked-eye visibility model filters these entries; it is not a prediction of stars recorded by a camera. See STAR-ESTIMATE-METHOD.md for sources and assumptions. A constellation guide star does not represent the whole pattern.
- **Meteor calendar:** verified subset of the IMO 2026 Meteor Shower Calendar, https://www.imo.net/files/meteor-shower/cal2026.pdf , Jürgen Rendtel, IMO INFO(3-25). Source pages, date precision and active dates are in events.json. Static 2026 subset, not a live event feed; dates do not roll into future years. Planetary close approaches and eclipses are calculated, not copied from this calendar.
- **State outlines:** US Census Bureau 2024 cartographic boundaries, https://www2.census.gov/geo/tiger/GENZ2024/shp/cb_2024_us_state_500k.zip , simplified and embedded in state-shapes.js.
- **Phone tutorial sources:** Apple Level https://support.apple.com/guide/iphone/iphbd435673d/ios ; Apple Compass https://support.apple.com/guide/iphone/iph1ac0b663/ios ; Apple Night mode https://support.apple.com/102519 ; Vieyra https://www.vieyrasoftware.net/ ; Pixel Camera https://support.google.com/pixelcamera/answer/9708795 . Features and sensor availability vary by device.

## Edit and build

Edit the template, CSS and JS modules, then run:

    python3 build.py

This rebuilds the self-contained index.html and service-worker cache version. All dependency/data licenses and source subsets are included. No npm install is needed to run or rebuild the delivered app.

## Naked-eye star estimate: what changed

The former ~2,000 display was geometry only: all HYG stars brighter than magnitude6 above10°, regardless of light pollution. It is replaced with a location- and time-dependent model counting actual HYG entries against a modeled visibility threshold.

The model uses Crumey(2014), *Human contrast threshold and astronomical visibility*, the full Eq34/Blackwell Eq28 contrast model, with a monotonic threshold envelope to remove the fit’s small nonphysical bright-background turnover, and a nominal observer/field factor2 and1.4–2.4 observer scenarios. Sky brightness comes from the archived atlas category/range. Krisciunas & Schaefer(1991), *A model of the brightness of moonlight*, supplies a Moon-phase/altitude/separation skyglow approximation for each star direction. Differential atmospheric extinction is assumed; terrain, immediate glare, haze, eyesight and adaptation are not measured.

The displayed range is a scenario envelope, **not a statistical confidence interval**. Cloud opacity/position cannot be derived from a single forecast coverage percentage, so cloud forecasts are shown as warnings without inventing a uniform numerical reduction. In daylight/twilight the app reports no nighttime estimate. Camera photos can record different numbers of stars depending on optics/exposure; this is an unaided-eye estimate.

Source papers: https://crumey.co.uk/archive/astro/mnras.pdf and https://articles.adsabs.harvard.edu/pdf/1991PASP..103.1033K . More exact equations and sensitivity assumptions are in STAR-ESTIMATE-METHOD.md and star-estimate.js. A model is not an on-site measurement; the archived2015 sky layer remains a limitation.
