/* Nocturne live-weather adapter. Data: Open-Meteo Forecast API (model forecasts).
 * Documentation and attribution: https://open-meteo.com/en/docs
 * Forecast request: public endpoint, no embedded API key. Check provider terms
 * before commercial deployment. This module never generates demonstration weather.
 */
(function (global) {
  'use strict';
  var ENDPOINT = 'https://api.open-meteo.com/v1/forecast';
  var SOURCE = 'Open-Meteo Forecast API';
  var DOCS = 'https://open-meteo.com/en/docs';
  var PREFIX = 'nocturne.weather.v2.';
  var DAY = 24 * 60 * 60 * 1000;
  var pending = new Map();
  var memory = new Map();
  var fields = {
    cloud: 'cloud_cover', low: 'cloud_cover_low', mid: 'cloud_cover_mid',
    high: 'cloud_cover_high', precip: 'precipitation_probability',
    wind: 'wind_speed_10m', humidity: 'relative_humidity_2m',
    temp: 'temperature_2m', dew: 'dew_point_2m'
  };
  var units = Object.freeze({time: 'UTC ISO 8601', cloud: '%', low: '%', mid: '%',
    high: '%', precip: '%', wind: 'km/h', humidity: '%', temp: '°C', dew: '°C'});

  function coordinates(lat, lon) {
    if (typeof lat !== 'number' || typeof lon !== 'number' || !Number.isFinite(lat) ||
        !Number.isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
      throw new Error('Choose a valid latitude and longitude before requesting weather.');
    }
    return [Math.round(lat * 10000) / 10000, Math.round(lon * 10000) / 10000];
  }
  function key(lat, lon) { return PREFIX + lat.toFixed(4) + ',' + lon.toFixed(4); }
  function numberOrNull(value, field) {
    if (typeof value !== 'number' || !Number.isFinite(value)) return null;
    if (['cloud', 'low', 'mid', 'high', 'precip', 'humidity'].includes(field) &&
        (value < 0 || value > 100)) return null;
    if (field === 'wind' && value < 0) return null;
    return value;
  }
  function validData(data) {
    if (!data || typeof data !== 'object' || !Array.isArray(data.hours) ||
        !data.hours.length || data.hours.length > 500) return false;
    try { coordinates(data.lat, data.lon); } catch (_) { return false; }
    var previous = -Infinity, hasCloud = false;
    for (var hour of data.hours) {
      if (!hour || typeof hour.time !== 'string') return false;
      var timestamp = Date.parse(hour.time);
      if (!Number.isFinite(timestamp) || timestamp <= previous) return false;
      if (previous !== -Infinity && timestamp - previous !== 3600000) return false;
      previous = timestamp;
      for (var field of Object.keys(fields)) {
        if (hour[field] !== null && numberOrNull(hour[field], field) !== hour[field]) return false;
      }
      if (hour.cloud !== null) hasCloud = true;
    }
    return hasCloud;
  }
  function validRecord(record, lat, lon) {
    if (!record || record.version !== 2 || record.source !== SOURCE ||
        !Number.isFinite(Date.parse(record.fetchedAt)) ||
        Date.parse(record.fetchedAt) > Date.now() + 300000 || !validData(record.data)) return false;
    return Math.abs(record.data.lat - lat) < .00011 && Math.abs(record.data.lon - lon) < .00011;
  }
  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function read(lat, lon) {
    var id = key(lat, lon), record = memory.get(id);
    if (record && validRecord(record, lat, lon)) return record;
    try {
      record = JSON.parse(global.localStorage.getItem(id) || 'null');
      if (validRecord(record, lat, lon)) { memory.set(id, record); return record; }
    } catch (_) { /* Private browsing and full storage still permit in-memory caching. */ }
    return null;
  }
  function save(record) {
    var id = key(record.data.lat, record.data.lon), previous = read(record.data.lat, record.data.lon);
    if (previous && Date.parse(previous.fetchedAt) > Date.parse(record.fetchedAt)) return;
    memory.set(id, record);
    try { global.localStorage.setItem(id, JSON.stringify(record)); } catch (_) {}
  }
  function isStale(record) {
    return Date.now() - Date.parse(record.fetchedAt) >= DAY ||
      Date.parse(record.data.forecastEnd) <= Date.now();
  }
  function result(record, cached, error) {
    return {
      data: record ? clone(record.data) : null,
      fetchedAt: record ? record.fetchedAt : null,
      source: SOURCE,
      sourceUrl: DOCS,
      stale: !!error || !record || isStale(record),
      cached: !!cached,
      error: error || null
    };
  }
  function normalize(raw, lat, lon, requestUrl) {
    if (!raw || raw.error || !raw.hourly || !Array.isArray(raw.hourly.time) ||
        !Array.isArray(raw.hourly.cloud_cover)) {
      throw new Error('The weather service returned an incomplete hourly forecast.');
    }
    var hours = raw.hourly.time.map(function (seconds, index) {
      if (typeof seconds !== 'number' || !Number.isFinite(seconds) ||
          Math.abs(seconds) > 8640000000000) throw new Error('The forecast contains invalid timestamps.');
      var row = {time: new Date(seconds * 1000).toISOString()};
      for (var field of Object.keys(fields)) {
        var values = raw.hourly[fields[field]];
        row[field] = numberOrNull(Array.isArray(values) ? values[index] : null, field);
      }
      return row;
    });
    var data = {
      lat: lat, lon: lon,
      gridLat: typeof raw.latitude === 'number' ? raw.latitude : null,
      gridLon: typeof raw.longitude === 'number' ? raw.longitude : null,
      elevation: typeof raw.elevation === 'number' ? raw.elevation : null,
      hours: hours, units: Object.assign({}, units), timezone: 'UTC',
      forecastStart: hours.length ? hours[0].time : null,
      forecastEnd: hours.length ? hours[hours.length - 1].time : null,
      requestUrl: requestUrl,
      kind: 'Model forecast; not an observation',
      modelRunAt: null
    };
    if (!validData(data)) throw new Error('The weather service returned invalid or missing cloud-cover data.');
    return data;
  }
  async function fetchRecord(lat, lon) {
    var params = new URLSearchParams({latitude: String(lat), longitude: String(lon),
      hourly: Object.values(fields).join(','), timezone: 'UTC', timeformat: 'unixtime',
      forecast_days: '9', temperature_unit: 'celsius', wind_speed_unit: 'kmh'});
    var query = params.toString(), url = ENDPOINT + '?' + query, candidates = [url];
    // The optional local launcher forwards only this provider's fixed endpoint.
    // Static hosted copies and file:// field packs continue to call Open-Meteo.
    var location = global.location;
    if (location && ['http:', 'https:'].includes(location.protocol) &&
        ['localhost', '127.0.0.1', '[::1]', '::1'].includes(location.hostname)) {
      var directory = location.pathname.slice(0, location.pathname.lastIndexOf('/') + 1);
      candidates.unshift(location.origin + directory + 'api/weather?' + query);
    }
    var controller = typeof global.AbortController === 'function' ? new global.AbortController() : null;
    var timer, timedOut = false, timeout = new Promise(function (_, reject) {
      timer = global.setTimeout(function () {
        timedOut = true;
        if (controller) controller.abort();
        reject(new Error('The forecast request timed out. Check your connection and refresh again.'));
      }, 15000);
    });
    try {
      var data;
      for (var i = 0; i < candidates.length; i++) {
        try {
          var response = await Promise.race([global.fetch(candidates[i], {
            signal: controller ? controller.signal : undefined, cache: 'no-store',
            headers: {'Accept': 'application/json'}
          }), timeout]);
          if (!response.ok) throw new Error('The weather service returned HTTP ' + response.status + '. Try refreshing later.');
          var raw = await Promise.race([response.json(), timeout]);
          data = normalize(raw, lat, lon, url);
          break;
        } catch (error) {
          // A missing launcher route, connection failure, or invalid proxy response
          // falls back to the actual provider within the same total 15s deadline.
          if (timedOut || i === candidates.length - 1) throw error;
        }
      }
      var record = {version: 2, source: SOURCE, sourceUrl: DOCS,
        fetchedAt: new Date().toISOString(), data: data};
      save(record);
      return record;
    } finally { global.clearTimeout(timer); }
  }
  async function get(lat, lon, options) {
    var coords = coordinates(lat, lon); lat = coords[0]; lon = coords[1];
    var old = read(lat, lon), force = !!(options && options.force), id = key(lat, lon);
    if (!force && old && !isStale(old)) return result(old, true);
    if (!pending.has(id)) {
      pending.set(id, fetchRecord(lat, lon).finally(function () { pending.delete(id); }));
    }
    try { return result(await pending.get(id), false); }
    catch (error) {
      old = read(lat, lon);
      var message = error && error.message ? error.message : 'Weather is unavailable. Check your connection and refresh.';
      if (error && error.name === 'AbortError') message = 'The forecast request timed out. Please refresh again.';
      return result(old, !!old, message);
    }
  }
  function peek(lat, lon) {
    var coords = coordinates(lat, lon), record = read(coords[0], coords[1]);
    return record ? result(record, true) : null;
  }
  function exportCache(lat, lon) {
    var coords = coordinates(lat, lon), record = read(coords[0], coords[1]);
    return record ? clone(record) : null;
  }
  function importCache(snapshot) {
    if (!snapshot || !snapshot.data) throw new Error('This field pack has no forecast snapshot.');
    var coords = coordinates(snapshot.data.lat, snapshot.data.lon);
    if (!validRecord(snapshot, coords[0], coords[1])) throw new Error('This field pack has an invalid forecast snapshot.');
    save(clone(snapshot));
    return result(read(coords[0], coords[1]), true);
  }
  global.NocturneWeather = Object.freeze({
    get: get, peek: peek, exportCache: exportCache, importCache: importCache,
    source: SOURCE, sourceUrl: DOCS, maxCacheAgeMs: DAY, units: units
  });
})(typeof window !== 'undefined' ? window : globalThis);
