/* Nocturne naked-eye visibility estimate v1.
 * Crumey (2014), MNRAS442,2600–2619, Eq34/28 with a monotonic threshold envelope;
 * nominal observer/field factorF=2,
 * scenario1.4–2.4 (§3.1). Moon skyglow: Krisciunas&Schaefer(1991), PASP103,
 * 1033–1039, Eq3,15,20,21 (+Eq19 close-angleMie term).
 * This is a conditional estimate, not a measured star count or calibrated forecast.
 */
(function(root){
'use strict';
const RAD=Math.PI/180,VERSION='Nocturne naked-eye model 1.1',cache=new Map();
const sources=Object.freeze({visibility:{name:'Crumey(2014), Human contrast threshold and astronomical visibility, Eq34/28 + monotonic envelope',url:'https://crumey.co.uk/archive/astro/mnras.pdf',doi:'https://doi.org/10.1093/mnras/stu992',note:'Full Blackwell point-source fit (Eq34 coefficients28), with an app monotonic-envelope regularization of its small mesopic turnover. Default field factor2; scenario1.4–2.4 from §3.1. No empirical accuracy claim is made for this adaptation.'},moon:{name:'Krisciunas&Schaefer(1991), A model of the brightness of moonlight, Eq3/15/19/20/21',url:'https://articles.adsabs.harvard.edu/pdf/1991PASP..103.1033K',doi:'https://doi.org/10.1086/132921',note:'Moon phase, altitude and angular separation; assumed extinction0.20mag/airmass. Clear atmosphere, not real-time aerosol measurement.'},stars:{name:'HYG v4.1, actual magnitude≤8.0 subset',url:'https://github.com/astronexus/HYG-Database',license:'CC BY-SA4.0'},sky:{name:'World Atlas2015 category-derived sky brightness',url:'https://doi.org/10.5880/GFZ.1.4.2016.001',license:'CC BY-NC4.0',note:'Historic quantized modeled zenith brightness, not a current sky measurement.'}});
let preparedRef=null,stars=[];
function prepare(){if(preparedRef===root.NocturneStars)return;preparedRef=root.NocturneStars;stars=(preparedRef||[]).filter(s=>Number.isFinite(s.ra)&&Number.isFinite(s.dec)&&Number.isFinite(s.mag)).map(s=>{const ra=s.ra*15*RAD,dec=s.dec*RAD,c=Math.cos(dec);return{x:c*Math.cos(ra),y:c*Math.sin(ra),z:Math.sin(dec),mag:s.mag}});cache.clear()}
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
function brightnessFromMag(mu){return 108000*Math.pow(10,-.4*mu)}
// Crumey2014 Eq34 with Blackwell coefficients Eq28, valid across scotopic,
// mesopic and photopic point-source data. Do not extrapolate Eq53 into bright glare.
const fullCoefficients=[5.949e-8,-2.389e-7,2.459e-7,4.120e-4,-4.225e-4];
function rawThreshold(B){const t=Math.pow(B,.25),[a,b,c,d,e]=fullCoefficients,q=a+b*t+c*t*t,p=t*(Math.sqrt(Math.max(0,q))+d+e*t);return p*p}
function thresholdDerivativeSign(B){const t=Math.pow(B,.25),[a,b,c,d,e]=fullCoefficients,q=Math.sqrt(a+b*t+c*t*t);return q+d+2*e*t+t*(b+2*c*t)/(2*q)}
// The empirical full fit has a small (~0.03mag) turnover in the mesopic
// transition. Preserve its maximum required illuminance until the fit exceeds
// it again; added background must not make a star easier in this planning app.
// This regularization is an app assumption, not a claim of fresh validation.
const thresholdPeaks=[];
(function(){let previous=1e-5,sign=thresholdDerivativeSign(previous);for(let i=1;i<=1024;i++){const B=Math.pow(10,-5+i*(Math.log10(3426)+5)/1024),next=thresholdDerivativeSign(B);if(sign>0&&next<0){let lo=previous,hi=B;for(let j=0;j<60;j++){const mid=(lo+hi)/2;if(thresholdDerivativeSign(mid)>0)lo=mid;else hi=mid}const peak=(lo+hi)/2;thresholdPeaks.push({brightness:peak,threshold:rawThreshold(peak)})}previous=B;sign=next}})();
function limitingMagnitude(B,F=2){if(!(B>0)||!(F>0)||B>3426)return null;B=Math.max(1e-5,B);let threshold=rawThreshold(B);for(const peak of thresholdPeaks)if(B>=peak.brightness)threshold=Math.max(threshold,peak.threshold);return -2.5*Math.log10(F*threshold/2.54e-6)}
// Rozenberg extinction air mass (KS1991 Eq14); excess over zenith only.
function extinctionAirMass(alt){const c=Math.sin(alt*RAD);return 1/(c+.025*Math.exp(-11*c))}
// KS1991 Eq3 scattering air mass (distinct from direct stellar extinction).
function scatteringAirMass(alt){return 1/Math.sqrt(1-.96*Math.pow(Math.cos(alt*RAD),2))}
function moonBackground(alt,separation,moon){if(!moon.aboveHorizon)return 0;const rho=Math.max(.25,separation),a=moon.phaseAngle,I=Math.pow(10,-.4*(3.84+.026*a+4e-9*Math.pow(a,4))),rayleigh=Math.pow(10,5.36)*(1.06+Math.pow(Math.cos(rho*RAD),2)),mie=rho<10?6.2e7/(rho*rho):Math.pow(10,6.15-rho/40),X=scatteringAirMass(alt),Xm=scatteringAirMass(moon.altitude),k=.20;
// Returned nanoLamberts are converted to cd/m²:1nL=(10^-5/pi)cd/m².
return(rayleigh+mie)*I*Math.pow(10,-.4*k*Xm)*(1-Math.pow(10,-.4*k*X))*(1e-5/Math.PI)}
function invalid(status,notes=[],sky=null){return{count:null,lower:null,upper:null,clearSkyCount:0,clearSkyLower:0,clearSkyUpper:0,limitingMag:null,minimumAltitude:10,status,moon:null,cloudCover:null,cloudFetchedAt:null,conditionNotes:notes,assumptions:[],modelVersion:VERSION,sources,label:'Estimated naked-eye stars · unavailable',sky}}
function estimate(date,site,options={}){
 prepare();date=new Date(date);const lat=Number(site?.lat),lon=Number(site?.lon);if(!Number.isFinite(+date)||!Number.isFinite(lat)||!Number.isFinite(lon)||lat<-90||lat>90||lon<-180||lon>180)return invalid('unavailable',['Invalid observation date or coordinates.']);
 const sky=options.skyOverride||root.NocturneLightPollution?.lookup(lat,lon);if(!sky?.available||!Number.isFinite(sky.skyMag))return invalid('unavailable',['A sourced sky-brightness estimate is needed at this location.'],sky);
 const cloud=Number.isFinite(options.cloudCover)?clamp(options.cloudCover,0,100):null,cloudStamp=typeof options.cloudFetchedAt==='string'?options.cloudFetchedAt:null;
 const key=[Math.round(+date/60000),lat.toFixed(5),lon.toFixed(5),sky.skyMag,JSON.stringify(sky.skyMagRange),cloud,cloudStamp,!!options.disableMoon].join('|');if(cache.has(key))return cache.get(key);
 const Astro=root.NocturneAstro,Engine=root.Astronomy;if(!Astro||!Engine||!stars.length)return invalid('unavailable',['Astronomy engine or star catalog unavailable.'],sky);
 const sun=Astro.sunAlt(date,lat,lon),m=Astro.moon(date,lat,lon),illum=Engine.Illumination(Engine.Body.Moon,date),moon={aboveHorizon:m.alt>0,altitude:m.alt,illumination:m.illumination,phaseAngle:illum.phase_angle,modeled:!options.disableMoon};
 const jd=+date/86400000+2440587.5,T=(jd-2451545)/36525,lst=(280.46061837+360.98564736629*(jd-2451545)+.000387933*T*T-T*T*T/38710000+lon)*RAD,sp=Math.sin(lat*RAD),cp=Math.cos(lat*RAD),cl=Math.cos(lst),sl=Math.sin(lst);
 const rot=Engine.Rotation_EQJ_EQD(date),basis=[[1,0,0],[0,1,0],[0,0,1]].map(v=>Engine.RotateVector(rot,new Engine.Vector(v[0],v[1],v[2],date))),mr=m.ra*15*RAD,md=m.dec*RAD,mc=Math.cos(md),moonVec=[mc*Math.cos(mr),mc*Math.sin(mr),Math.sin(md)];
 const range=Array.isArray(sky.skyMagRange)?sky.skyMagRange:[sky.skyMag-.15,sky.skyMag+.15],brightMu=Number.isFinite(range[0])?range[0]:null,darkMu=Number.isFinite(range[1])?range[1]:sky.skyMag,base=brightnessFromMag(sky.skyMag),bright=brightMu===null?null:brightnessFromMag(brightMu),dark=brightnessFromMag(darkMu);
 let count=0,lower=0,upper=0,clear=0,clearLower=0,clearUpper=0;const nominalLimit=limitingMagnitude(base,2),clearLowLimit=bright===null?null:limitingMagnitude(bright,2.4),clearHighLimit=limitingMagnitude(dark,1.4),moonActive=moon.aboveHorizon&&!options.disableMoon;if(nominalLimit===null)return invalid('unavailable',['Sky brightness is outside the scotopic visibility model domain.'],sky);
 for(const star of stars){
  if(clearHighLimit!==null&&star.mag>Math.max(clearHighLimit,nominalLimit))continue;
  const x=star.x*basis[0].x+star.y*basis[1].x+star.z*basis[2].x,y=star.x*basis[0].y+star.y*basis[1].y+star.z*basis[2].y,z=star.x*basis[0].z+star.y*basis[1].z+star.z*basis[2].z,sinAlt=clamp(sp*z+cp*(x*cl+y*sl),-1,1),alt=Math.asin(sinAlt)/RAD;if(alt<10)continue;
  const excess=Math.max(0,extinctionAirMass(alt)-1),nominalExt=.20*excess,lowExt=.30*excess,highExt=.12*excess;
  if(star.mag<=nominalLimit-nominalExt)clear++;if(clearLowLimit!==null&&star.mag<=clearLowLimit-lowExt)clearLower++;if(clearHighLimit!==null&&star.mag<=clearHighLimit-highExt)clearUpper++;
  if(!moonActive)continue;let add=0;if(moonActive){const rho=Math.acos(clamp(x*moonVec[0]+y*moonVec[1]+z*moonVec[2],-1,1))/RAD;add=moonBackground(alt,rho,moon)}
  let nominal=limitingMagnitude(base+add,2),lo=bright===null?null:limitingMagnitude(bright+add*1.5,2.4),hi=limitingMagnitude(dark+add*.5,1.4);if(nominal!==null)nominal=Math.min(nominal,nominalLimit);if(lo!==null&&clearLowLimit!==null)lo=Math.min(lo,clearLowLimit);if(hi!==null&&clearHighLimit!==null)hi=Math.min(hi,clearHighLimit);
  if(nominal!==null&&star.mag<=nominal-nominalExt)count++;if(lo!==null&&star.mag<=lo-lowExt)lower++;if(hi!==null&&star.mag<=hi-highExt)upper++;
 }
 if(!moonActive){count=clear;lower=clearLower;upper=clearUpper}
 const zenithMoon=moonActive?moonBackground(90,90-moon.altitude,moon):0,zenithLimit=limitingMagnitude(base+zenithMoon,2);
 const status=sun>=-6?'daylight':sun>-18?'twilight':'night',notes=[];
 if(status!=='night')notes.push('The naked-eye night model is not valid in daylight/twilight; only the hypothetical moonless-night potential is retained.');
 if(moon.aboveHorizon&&!options.disableMoon)notes.push('Moonlight is modeled by phase, altitude and angular separation. Atmospheric extinction and scattering are assumed, not measured.');else notes.push('Moon is below the horizon, or Moon correction was disabled.');
 if(cloud===null)notes.push('Cloud cover unavailable: clear sky assumed.');else notes.push(`${Math.round(cloud)}% forecast cloud cover${cloudStamp?' (retrieved '+cloudStamp+')':''}. Clouds are not a uniform star screen; their positions/opacity are unknown, so this clear-sky estimate is not numerically multiplied by cloud percentage.`);
 if(cloud!==null&&cloud>=50)notes.push('Clouds may obscure much of the sky. This number is clear-sky potential, not a prediction of stars visible through the forecast clouds.');
 const result={count:status==='night'?count:null,lower:status==='night'?Math.min(lower,count):null,upper:status==='night'?Math.max(upper,count):null,clearSkyCount:clear,clearSkyLower:clearLower,clearSkyUpper:clearUpper,limitingMag:zenithLimit===null?null:Math.min(nominalLimit,zenithLimit),moonlessLimitingMag:nominalLimit,minimumAltitude:10,status,moon,cloudCover:cloud,cloudFetchedAt:cloudStamp,conditionNotes:notes,assumptions:['Historic2015 atlas zenith brightness assumed representative across the sky; directional light domes, new lighting, terrain and glare are not measured.','Crumey Eq34/28 full point-source fit with a monotonic threshold envelope; field factor2 nominal,1.4–2.4 scenario. This app regularization and scenario range are not field validation or a confidence interval.','Stars above10° only; differential extinction0.20mag/airmass nominal with0.12–0.30 scenario bounds.','If Moon is up, KS1991 skyglow is added for each star;0.5–1.5 Moon-scattering scaling is an app sensitivity assumption, not a measured forecast uncertainty.','Cloud positions and opacity, smoke, eyesight, adaptation and unresolved multiple stars can change the actual visible count.','HYG≤8.0 catalog entries are evaluated; count is not a camera exposure or photographic-star prediction.'],modelVersion:VERSION,sources,label:'Estimated naked-eye stars · clear sky assumed',sky:{sourceYear:sky.sourceYear||2015,skyMag:sky.skyMag,skyMagRange:range,bortle:sky.bortle,bortleRange:sky.bortleRange},sunAltitude:sun};
 cache.set(key,result);if(cache.size>150)cache.delete(cache.keys().next().value);return result;
}
root.NocturneStarEstimate=Object.freeze({estimate,limitingMagnitude,brightnessFromMag,modelVersion:VERSION,sources});
})(typeof window!=='undefined'?window:globalThis);
