/* Nocturne astronomy adapter. Astronomy Engine 2.1.19 (MIT) + OpenNGC subset (CC BY-SA 4.0). */
(function(root){
"use strict";
const A=root.Astronomy;
if(!A)throw new Error("Astronomy Engine must load before astro.js");
const galaxies=[{"id": "m31", "name": "Andromeda", "catalog": "M31", "ngc": "NGC0224", "ra": 0.7123194444444444, "dec": 41.26905555555555, "mag": 3.44, "season": "Autumn", "gear": "Large field · telephoto / tracked", "type": "galaxy", "source": "OpenNGC", "sourceUrl": "https://github.com/mattiaverga/OpenNGC", "surfaceBrightness": 23.63}, {"id": "m33", "name": "Triangulum", "catalog": "M33", "ngc": "NGC0598", "ra": 1.5641361111111112, "dec": 30.66022222222222, "mag": 5.79, "season": "Autumn", "gear": "Faint surface brightness · tracked", "type": "galaxy", "source": "OpenNGC", "sourceUrl": "https://github.com/mattiaverga/OpenNGC", "surfaceBrightness": 23.61}, {"id": "m81", "name": "Bode’s Galaxy", "catalog": "M81", "ngc": "NGC3031", "ra": 9.925880555555555, "dec": 69.06530555555555, "mag": 6.92, "season": "Spring", "gear": "Small field · telescope / tracked", "type": "galaxy", "source": "OpenNGC", "sourceUrl": "https://github.com/mattiaverga/OpenNGC", "surfaceBrightness": 22.78}, {"id": "m82", "name": "Cigar Galaxy", "catalog": "M82", "ngc": "NGC3034", "ra": 9.931313888888889, "dec": 69.6793888888889, "mag": 8.3, "season": "Spring", "gear": "Small field · telescope / tracked", "type": "galaxy", "source": "OpenNGC", "sourceUrl": "https://github.com/mattiaverga/OpenNGC", "surfaceBrightness": 22.22}, {"id": "m104", "name": "Sombrero", "catalog": "M104", "ngc": "NGC4594", "ra": 12.666508333333333, "dec": -11.623055555555556, "mag": 8.59, "season": "Spring", "gear": "Small field · telescope / tracked", "type": "galaxy", "source": "OpenNGC", "sourceUrl": "https://github.com/mattiaverga/OpenNGC", "surfaceBrightness": 22.26}, {"id": "m51", "name": "Whirlpool", "catalog": "M51", "ngc": "NGC5194", "ra": 13.497974999999999, "dec": 47.195166666666665, "mag": 8.36, "season": "Spring", "gear": "Small field · telescope / tracked", "type": "galaxy", "source": "OpenNGC", "sourceUrl": "https://github.com/mattiaverga/OpenNGC", "surfaceBrightness": 22.9}, {"id": "m101", "name": "Pinwheel", "catalog": "M101", "ngc": "NGC5457", "ra": 14.053483333333334, "dec": 54.34894444444445, "mag": 7.9, "season": "Spring", "gear": "Faint surface brightness · tracked", "type": "galaxy", "source": "OpenNGC", "sourceUrl": "https://github.com/mattiaverga/OpenNGC", "surfaceBrightness": 23.97}];
const DAY=86400000,dirs=['N','NE','E','SE','S','SW','W','NW'];
const source={name:'Astronomy Engine',version:'2.1.19',url:'https://github.com/cosinekitty/astronomy',license:'MIT',kind:'Calculated ephemeris, not a live observation feed'};
const catalogSource={name:'OpenNGC',url:'https://github.com/mattiaverga/OpenNGC',datasetUrl:'https://github.com/mattiaverga/OpenNGC/blob/be3cd6c5498806a2fbb2f7e0452ef802dbb02be0/database_files/NGC.csv',version:'be3cd6c5498806a2fbb2f7e0452ef802dbb02be0',retrieved:'2026-10-30',license:'CC BY-SA 4.0',credit:'Mattia Verga and OpenNGC contributors',description:'Seven actual catalog rows; coordinates J2000; V-band integrated magnitude. Seasonal and gear labels are editorial guidance.'};
const asDate=d=>d instanceof Date?d:new Date(d);
const obs=(lat,lon)=>new A.Observer(+lat,+lon,0);
function horizontal(eq,date,observer){const h=A.Horizon(date,observer,eq.ra,eq.dec);return{alt:h.altitude,az:h.azimuth,dir:dirs[Math.round(h.azimuth/45)%8],ra:eq.ra,dec:eq.dec};}
// Input star/galaxy coordinates are J2000. Precess/nutate to equator of date.
function position(ra,dec,date,lat,lon){date=asDate(date);const v=A.VectorFromSphere(new A.Spherical(+dec,+ra*15,1),date),vd=A.RotateVector(A.Rotation_EQJ_EQD(date),v),eq=A.EquatorFromVector(vd);return horizontal(eq,date,obs(lat,lon));}
function bodyPosition(body,date,lat,lon){date=asDate(date);const observer=obs(lat,lon),eq=A.Equator(body,date,observer,true,true);return horizontal(eq,date,observer);}
function sunAlt(date,lat,lon){return bodyPosition(A.Body.Sun,date,lat,lon).alt;}
function phaseName(angle){if(angle<11.25||angle>=348.75)return'New Moon';if(angle<78.75)return'Waxing crescent';if(angle<101.25)return'First quarter';if(angle<168.75)return'Waxing gibbous';if(angle<191.25)return'Full Moon';if(angle<258.75)return'Waning gibbous';if(angle<281.25)return'Third quarter';return'Waning crescent';}
function moon(date,lat,lon){date=asDate(date);const p=bodyPosition(A.Body.Moon,date,lat,lon),illum=A.Illumination(A.Body.Moon,date),phaseAngle=A.MoonPhase(date);return{...p,phaseAngle,illumination:illum.phase_fraction,phaseName:phaseName(phaseAngle),distanceKm:illum.geo_dist*149597870.7,magnitude:illum.mag};}
function moonSeparation(ra,dec,date,lat,lon){const p=position(ra,dec,date,lat,lon),m=moon(date,lat,lon),rad=Math.PI/180;return Math.acos(Math.max(-1,Math.min(1,Math.sin(p.dec*rad)*Math.sin(m.dec*rad)+Math.cos(p.dec*rad)*Math.cos(m.dec*rad)*Math.cos((p.ra-m.ra)*15*rad))))/rad;}
function localParts(date,tz){const parts=new Intl.DateTimeFormat('en-CA',{timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(date);const out={};for(const p of parts)if(p.type!=='literal')out[p.type]=Number(p.value);return out;}
// Resolve local civil time using Intl; on DST gaps pick first later matching wall time.
function localDateTime(day,hour=0,tz='America/Los_Angeles'){
 const[y,m,d]=day.split('-').map(Number),whole=Math.floor(hour),minute=Math.round((hour-whole)*60),wall=Date.UTC(y,m-1,d,whole,minute,0);let t=wall;
 for(let i=0;i<4;i++){const p=localParts(new Date(t),tz),shown=Date.UTC(p.year,p.month-1,p.day,p.hour,p.minute,p.second),delta=wall-shown;if(!delta)break;t+=delta;}
 const finalParts=localParts(new Date(t),tz),shown=Date.UTC(finalParts.year,finalParts.month-1,finalParts.day,finalParts.hour,finalParts.minute,finalParts.second);if(shown<wall)t+=wall-shown;
 return new Date(t);
}
function nextDay(day){const d=new Date(day+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+1);return d.toISOString().slice(0,10);}
function moonTimes(day,lat,lon,tz='America/Los_Angeles'){
 const start=localDateTime(day,0,tz),end=localDateTime(nextDay(day),0,tz),observer=obs(lat,lon),duration=(end-start)/DAY;
 const rise=A.SearchRiseSet(A.Body.Moon,observer,1,start,duration),set=A.SearchRiseSet(A.Body.Moon,observer,-1,start,duration),r=rise&&rise.date<end?rise.date:null,s=set&&set.date<end?set.date:null;
 return{rise:r,set:s,rises:r?[r]:[],sets:s?[s]:[],start,end,status:!r&&!s?(moon(start,lat,lon).alt>0?'Above horizon all civil day':'Below horizon all civil day'):'Calculated rise/set, standard refraction; terrain not included'};
}
function nextMoonPhases(afterDate,count=8){let q=A.SearchMoonQuarter(asDate(afterDate));const out=[];for(let i=0;i<Math.max(0,Math.min(32,count));i++){out.push({date:q.time.date,phase:['New Moon','First quarter','Full Moon','Third quarter'][q.quarter],quarter:q.quarter,illumination:[0,.5,1,.5][q.quarter],source:source.name,sourceUrl:source.url});q=A.NextMoonQuarter(q);}return out;}
function moonlightIndex(date,lat,lon,ra,dec){const m=moon(date,lat,lon),sep=Number.isFinite(ra)&&Number.isFinite(dec)?moonSeparation(ra,dec,date,lat,lon):null,above=Math.max(0,Math.sin(m.alt*Math.PI/180)),proximity=sep===null?1:.4+.6*Math.max(0,1-sep/180);return{value:100*m.illumination*above*proximity,moon:m,separation:sep,description:'Relative planning index = illumination × sin(Moon altitude) × target-proximity factor. Heuristic; not measured sky brightness.'};}
const eclipseCache=new Map();
function eclipses(afterDate,lat,lon,options={}){
 const date=asDate(afterDate),days=Math.min(1827,Math.max(1,options.days||365)),limit=date.getTime()+days*DAY,key=[date.toISOString().slice(0,10),lat,lon,days].join('|');if(eclipseCache.has(key))return eclipseCache.get(key);
 const out=[],observer=obs(lat,lon);let lunar=A.SearchLunarEclipse(date);
 for(let i=0;i<16&&lunar.peak.date.getTime()<=limit;i++){
  const peak=lunar.peak.date,start=new Date(+peak-lunar.sd_penum*60000),end=new Date(+peak+lunar.sd_penum*60000),pa=moon(peak,lat,lon).alt;
  let visible=false;for(let t=+start;t<=+end;t+=10*60000)if(moon(new Date(t),lat,lon).alt>0&&sunAlt(new Date(t),lat,lon)<0){visible=true;break;}
  const peakVisible=pa>0&&sunAlt(peak,lat,lon)<0;
  out.push({id:'lunar-'+peak.toISOString(),type:'lunar',name:lunar.kind[0].toUpperCase()+lunar.kind.slice(1)+' lunar eclipse',kind:lunar.kind,date:peak,start,end,localVisible:visible,localVisibility:peakVisible?'Moon above horizon at peak':visible?'Part of event above horizon; peak unavailable':'Not observable here during darkness',peakAlt:pa,obscuration:lunar.obscuration,source:source.name+' '+source.version,sourceUrl:source.url});
  lunar=A.NextLunarEclipse(lunar.peak);
 }
 let global=A.SearchGlobalSolarEclipse(date),local=null;
 // Local search returns future eclipse even if years away; match only same global event.
 try{local=A.SearchLocalSolarEclipse(date,observer);}catch(e){}
 for(let i=0;i<16&&global.peak.date.getTime()<=limit;i++){
  const globalPeak=global.peak.date,same=local&&Math.abs(local.peak.time.date-globalPeak)<DAY,visible=!!(same&&(local.peak.altitude>0||local.partial_begin.altitude>0||local.partial_end.altitude>0)),peak=same?local.peak.time.date:globalPeak;
  const kind=same?local.kind:global.kind;
  out.push({id:'solar-'+globalPeak.toISOString(),type:'solar',name:kind[0].toUpperCase()+kind.slice(1)+' solar eclipse',kind,date:peak,start:same?local.partial_begin.time.date:null,end:same?local.partial_end.time.date:null,localVisible:visible,localVisibility:visible?'At least part visible from selected coordinates':'Not visible from selected coordinates',peakAlt:same?local.peak.altitude:null,obscuration:same?local.obscuration:null,globalKind:global.kind,source:source.name+' '+source.version,sourceUrl:source.url});
  if(same){try{local=A.NextLocalSolarEclipse(local.peak.time,observer);}catch(e){local=null;}}
  global=A.NextGlobalSolarEclipse(global.peak);
 }
 out.sort((a,b)=>a.date-b.date);eclipseCache.set(key,out);return out;
}
root.NocturneAstro=Object.freeze({source,catalogSource,galaxies,sunAlt,moon,moonTimes,nextMoonPhases,position,bodyPosition,localDateTime,nextDay,moonSeparation,moonlightIndex,eclipses});
})(typeof window!=='undefined'?window:globalThis);
