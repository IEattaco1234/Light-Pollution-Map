from pathlib import Path
import json,re,hashlib
p=Path(__file__).parent
catalog="const spots=NocturneLocations.spots,origins=NocturneLocations.origins;"
mapcode=(p/'map.js').read_text()
parts=[(p/'astronomy.browser.min.js').read_text(),(p/'astro.js').read_text(),(p/'planets.js').read_text(),(p/'stars.js').read_text(),(p/'star-estimate.js').read_text(),(p/'star-ui.js').read_text(),(p/'weather.js').read_text(),(p/'light-pollution.js').read_text(),(p/'state-shapes.js').read_text(),(p/'locations.js').read_text(),catalog,(p/'targets-extra.js').read_text(),'const eventCatalog='+json.dumps(json.loads((p/'events.json').read_text()))+';',(p/'pin-controls.js').read_text(),(p/'location-controls.js').read_text(),(p/'sky-map-details.js').read_text(),mapcode,(p/'app.js').read_text(),(p/'beginner.js').read_text(),(p/'field-guide.js').read_text()]
bundle='\n;\n'.join(parts)
s=(p/'index.template.html').read_text().replace('/*BASE_CSS*/',(p/'base.css').read_text()).replace('/*UPGRADE_CSS*/',(p/'upgrade.css').read_text()+(p/'beginner.css').read_text()).replace('/*BUNDLE*/',bundle.replace('</script','<\\/script'))
(p/'index.html').write_text(s)
version=hashlib.sha256(s.encode()).hexdigest()[:12]
(p/'sw.js').write_text("""const CACHE='nocturne-%s';const ASSETS=['./','./index.html','./manifest.webmanifest','./icon192.png','./icon512.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('nocturne-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET'||new URL(e.request.url).origin!==self.location.origin||new URL(e.request.url).pathname.endsWith('/api/weather')||e.request.cache==='no-store')return;e.respondWith(fetch(e.request).then(r=>{if(r.ok){const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy))}return r}).catch(()=>caches.match(e.request).then(r=>r||(e.request.mode==='navigate'?caches.match('./index.html'):Response.error()))))});
"""%version)
print('Built index.html',len(s),'characters, cache',version)
