// Tracking is live and temporary; the pin button saves a fixed position explicitly.
let locationGeneration=0;

function renderLocationControls(){
  const tracking=watchId!==null,ready=tracking&&!!gps;
  $('gpsBtn').setAttribute('aria-pressed',String(tracking));
  $('gpsBtn').setAttribute('aria-busy',String(tracking&&!ready));
  $('gpsBtn').textContent=ready?'◎ Stop tracking':tracking?'◎ Cancel locating':'◎ Follow my location';
  $('useLocationBtn').disabled=!ready;
  $('useLocationBtn').title=ready?'Save this GPS position to the map and location list':'Enable location and wait for a GPS fix first';
}

function stopLocationTracking(message='Tracking stopped. Your saved pins are still available.'){
  ++locationGeneration; // Ignore any callbacks queued before tracking was stopped.
  if(watchId!==null)navigator.geolocation?.clearWatch(watchId);
  watchId=null;
  gps=null;
  regionalCache=null;
  renderLocationControls();
  $('gpsStatus').textContent=message;
  renderScout();
  renderBeginner();
}

function centerMapOnLocation(point){
  const [x,y]=project(point.lon,point.lat);
  mapView.x=x-mapView.w/2;
  mapView.y=y-mapView.h/2;
}

function toggleLocationTracking(){
  if(watchId!==null){stopLocationTracking();return}
  gps=null;
  renderLocationControls();
  if(!navigator.geolocation){
    $('gpsStatus').textContent='Location is unavailable in this browser. You can still save a point on the map.';
    return;
  }
  if(window.isSecureContext===false){
    $('gpsStatus').textContent='Location requires HTTPS or localhost. Open the app on a secure connection and try again.';
    return;
  }
  const generation=++locationGeneration;
  $('gpsStatus').textContent='Requesting location permission and finding your position…';
  try{
    watchId=navigator.geolocation.watchPosition(position=>{
      if(generation!==locationGeneration)return;
      const {latitude:lat,longitude:lon,accuracy}=position.coords;
      if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180){
        stopLocationTracking('The browser returned an invalid position. Enable location again to retry.');
        return;
      }
      const firstFix=!gps;
      gps={lat,lon,accuracy};
      regionalCache=null;
      renderLocationControls();
      const state=locateState(lat,lon),accuracyText=Number.isFinite(accuracy)?` · accuracy ±${Math.round(accuracy)} m`:'';
      $('gpsStatus').textContent=`Location on · ${lat.toFixed(5)}, ${lon.toFixed(5)}${accuracyText}. ${state?'Use the pin button to keep this spot in your location list.':'Your position is outside California and Nevada; saved GPS pins are supported within these states.'}`;
      if(firstFix&&state)centerMapOnLocation(gps);
      renderScout();
      renderBeginner();
    },error=>{
      if(generation!==locationGeneration)return;
      const message=error.code===1?'Location permission was denied or turned off. Allow location in your browser, then try again.':error.code===3?'Finding your location timed out. Enable location again to retry.':'Your location is unavailable. Enable location again to retry.';
      stopLocationTracking(message);
    },{enableHighAccuracy:true,maximumAge:15000,timeout:20000});
    renderLocationControls();
  }catch(error){
    stopLocationTracking('Location could not start. Check browser permission and use HTTPS or localhost.');
  }
}

function useLocationAsPin(){
  if(watchId===null||!gps){renderLocationControls();return}
  const {lat,lon}=gps,state=locateState(lat,lon);
  if(!state){toast('Your location is outside California and Nevada, the supported area for saved pins.');return}
  // Clear filters so the new pin is visible even when a search or darkness limit was active.
  $('search').value='';
  $('bortleFilter').value='9';
  $('stateFilter').value='all';
  onlySaved=false;
  let pin=spots.find(s=>s.custom&&Math.abs(s.lat-lat)<.00001&&Math.abs(s.lon-lon)<.00001);
  if(!pin){
    for(let i=spots.length-1;i>=0;i--)if(spots[i].custom&&spots[i].temporary)spots.splice(i,1);
    pin={id:'pin-'+lat.toFixed(5)+'-'+lon.toFixed(5),name:`Your location · ${state}`,region:`${lat.toFixed(4)}° N, ${Math.abs(lon).toFixed(4)}° W`,state,lat:+lat.toFixed(5),lon:+lon.toFixed(5),custom:true,temporary:false};
    spots.push(pin);
  }
  pin.temporary=false;
  applySkyRating(pin);
  selected=pin.id;
  nightCache=null;
  regionalCache=null;
  skyMapPopup={lat:pin.lat,lon:pin.lon,name:pin.name,id:pin.id};
  centerMapOnLocation(pin);
  saveMapPin(pin.id);
  loadWeather(false);
  const row=Array.from($('spots').querySelectorAll('[data-id]')).find(el=>el.dataset.id===pin.id);
  row?.scrollIntoView({block:'nearest',behavior:'smooth'});
  row?.focus({preventScroll:true});
}

function bortleBadgeInk(color){
  const rgb=parseInt(color.slice(1),16),linear=shift=>{
    const channel=((rgb>>shift)&255)/255;
    return channel<=.04045?channel/12.92:((channel+.055)/1.055)**2.4;
  };
  const luminance=.2126*linear(16)+.7152*linear(8)+.0722*linear(0);
  return luminance>.179?'#000000':'#ffffff';
}
